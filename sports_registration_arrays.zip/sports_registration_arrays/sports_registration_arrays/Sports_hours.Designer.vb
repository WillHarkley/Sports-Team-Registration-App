﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmhrs
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblHours = New System.Windows.Forms.Label()
        Me.lstSport = New System.Windows.Forms.ListBox()
        Me.btnAddHours = New System.Windows.Forms.Button()
        Me.lblSoccer = New System.Windows.Forms.Label()
        Me.lblSwimming = New System.Windows.Forms.Label()
        Me.lblFootball = New System.Windows.Forms.Label()
        Me.lstTotals = New System.Windows.Forms.ListBox()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.lblSoccerdisplay = New System.Windows.Forms.Label()
        Me.lblSwimmingdisplay = New System.Windows.Forms.Label()
        Me.lblFootballdisplay = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lblHours
        '
        Me.lblHours.AutoSize = True
        Me.lblHours.Location = New System.Drawing.Point(146, 110)
        Me.lblHours.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblHours.Name = "lblHours"
        Me.lblHours.Size = New System.Drawing.Size(52, 22)
        Me.lblHours.TabIndex = 0
        Me.lblHours.Text = "Hours"
        '
        'lstSport
        '
        Me.lstSport.FormattingEnabled = True
        Me.lstSport.ItemHeight = 22
        Me.lstSport.Location = New System.Drawing.Point(78, 191)
        Me.lstSport.Name = "lstSport"
        Me.lstSport.Size = New System.Drawing.Size(206, 180)
        Me.lstSport.TabIndex = 2
        Me.lstSport.TabStop = False
        '
        'btnAddHours
        '
        Me.btnAddHours.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnAddHours.Location = New System.Drawing.Point(117, 417)
        Me.btnAddHours.Name = "btnAddHours"
        Me.btnAddHours.Size = New System.Drawing.Size(100, 35)
        Me.btnAddHours.TabIndex = 3
        Me.btnAddHours.Text = "&Add Hours"
        Me.btnAddHours.UseVisualStyleBackColor = True
        '
        'lblSoccer
        '
        Me.lblSoccer.AutoSize = True
        Me.lblSoccer.Location = New System.Drawing.Point(405, 116)
        Me.lblSoccer.Name = "lblSoccer"
        Me.lblSoccer.Size = New System.Drawing.Size(54, 22)
        Me.lblSoccer.TabIndex = 4
        Me.lblSoccer.Text = "Soccer"
        '
        'lblSwimming
        '
        Me.lblSwimming.AutoSize = True
        Me.lblSwimming.Location = New System.Drawing.Point(395, 206)
        Me.lblSwimming.Name = "lblSwimming"
        Me.lblSwimming.Size = New System.Drawing.Size(85, 22)
        Me.lblSwimming.TabIndex = 6
        Me.lblSwimming.Text = "Swimming"
        '
        'lblFootball
        '
        Me.lblFootball.AutoSize = True
        Me.lblFootball.Location = New System.Drawing.Point(405, 299)
        Me.lblFootball.Name = "lblFootball"
        Me.lblFootball.Size = New System.Drawing.Size(65, 22)
        Me.lblFootball.TabIndex = 8
        Me.lblFootball.Text = "Football"
        '
        'lstTotals
        '
        Me.lstTotals.FormattingEnabled = True
        Me.lstTotals.ItemHeight = 22
        Me.lstTotals.Location = New System.Drawing.Point(569, 206)
        Me.lstTotals.Name = "lstTotals"
        Me.lstTotals.Size = New System.Drawing.Size(247, 136)
        Me.lstTotals.TabIndex = 11
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(117, 135)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(103, 29)
        Me.txtAmount.TabIndex = 12
        '
        'lblSoccerdisplay
        '
        Me.lblSoccerdisplay.AutoSize = True
        Me.lblSoccerdisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSoccerdisplay.Location = New System.Drawing.Point(409, 138)
        Me.lblSoccerdisplay.MinimumSize = New System.Drawing.Size(50, 50)
        Me.lblSoccerdisplay.Name = "lblSoccerdisplay"
        Me.lblSoccerdisplay.Size = New System.Drawing.Size(50, 50)
        Me.lblSoccerdisplay.TabIndex = 13
        '
        'lblSwimmingdisplay
        '
        Me.lblSwimmingdisplay.AutoSize = True
        Me.lblSwimmingdisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblSwimmingdisplay.Location = New System.Drawing.Point(409, 228)
        Me.lblSwimmingdisplay.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.lblSwimmingdisplay.MinimumSize = New System.Drawing.Size(50, 50)
        Me.lblSwimmingdisplay.Name = "lblSwimmingdisplay"
        Me.lblSwimmingdisplay.Size = New System.Drawing.Size(50, 50)
        Me.lblSwimmingdisplay.TabIndex = 14
        '
        'lblFootballdisplay
        '
        Me.lblFootballdisplay.AutoSize = True
        Me.lblFootballdisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFootballdisplay.Location = New System.Drawing.Point(409, 321)
        Me.lblFootballdisplay.MinimumSize = New System.Drawing.Size(50, 50)
        Me.lblFootballdisplay.Name = "lblFootballdisplay"
        Me.lblFootballdisplay.Size = New System.Drawing.Size(50, 50)
        Me.lblFootballdisplay.TabIndex = 15
        '
        'frmhrs
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Desktop
        Me.ClientSize = New System.Drawing.Size(852, 470)
        Me.Controls.Add(Me.lblFootballdisplay)
        Me.Controls.Add(Me.lblSwimmingdisplay)
        Me.Controls.Add(Me.lblSoccerdisplay)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.lstTotals)
        Me.Controls.Add(Me.lblFootball)
        Me.Controls.Add(Me.lblSwimming)
        Me.Controls.Add(Me.lblSoccer)
        Me.Controls.Add(Me.btnAddHours)
        Me.Controls.Add(Me.lstSport)
        Me.Controls.Add(Me.lblHours)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.Window
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MinimumSize = New System.Drawing.Size(0, 50)
        Me.Name = "frmhrs"
        Me.Text = "Sports Hours"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHours As Label
    Friend WithEvents lstSport As ListBox
    Friend WithEvents btnAddHours As Button
    Friend WithEvents lblSoccer As Label
    Friend WithEvents lblSwimming As Label
    Friend WithEvents lblFootball As Label
    Friend WithEvents lstTotals As ListBox
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblSoccerdisplay As Label
    Friend WithEvents lblSwimmingdisplay As Label
    Friend WithEvents lblFootballdisplay As Label
End Class
