﻿Public Class frmhrs

    Dim sports() As String = {"Soccer", "Swimming", "Football"}

    'inttotals               {ScHours         SwHours         FHours}

    Private Sub btnAddHours_Click(sender As Object, e As EventArgs) Handles btnAddHours.Click

        Dim inthours As Integer
        Dim strsport As String

        Static inttotals(2) As Integer

        strsport = lstSport.SelectedItem

        'error check
        Integer.TryParse(txtAmount.Text, inthours)

        Dim inttotalindex As Integer = lstSport.SelectedIndex
        inttotals(inttotalindex) = inttotals(inttotalindex) + inthours

        lblSoccerdisplay.Text = inttotals(0).ToString
        lblSwimmingdisplay.Text = inttotals(1).ToString
        lblFootballdisplay.Text = inttotals(2).ToString


        Dim strname As String = InputBox("Please enter who played the sport")
        If strname = "" Then
            MessageBox.Show("Please enter player name")
            Return
        End If
        lstTotals.Items.Add(getName(strname) & " played " & inthours & " hours")
        txtAmount.Text = ""
        lstSport.SelectedIndex = -1
    End Sub

    Function getName(ByVal newname As String) As String


        Dim index As Integer
        Dim lastname, firstname As String

        index = newname.IndexOf(" ")
        firstname = newname.Substring(0, index)
        lastname = newname.Substring(index + 1)

        Return firstname
    End Function

    Private Sub frmhrs_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 0 To sports.Count - 1
            lstSport.Items.Add(sports(i))
        Next
    End Sub

End Class
